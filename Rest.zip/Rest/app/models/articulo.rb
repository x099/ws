class Articulo < ApplicationRecord
end
